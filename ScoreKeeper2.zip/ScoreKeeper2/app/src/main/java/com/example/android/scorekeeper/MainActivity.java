/**
 * IMPORTANT: Make sure you are using the correct package name.
 * This example uses the package name:
 * package com.example.android.courtcounter
 * If you get an error when copying this code into Android studio, update it to match teh package name found
 * in the project's AndroidManifest.xml file.
 **/


package com.example.android.scorekeeper;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;


import com.example.android.scorekeeper.R;


import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {
    TextView myImageView;
    TextView myImageView1;
    Animation myAnimation;
    Animation myAnimation1;
    Animation myAnimation2;


    int scoreTeamA = 0;
    int scoreTeamB = 0;
    String winner = "winner";
    String loser = "loser";
    String same = "-";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //load the animation file (my_anim)
        myAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.my_anim);
        myAnimation1 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.my_anim);
        myAnimation2 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.my_anim1);


        //get my image
        myImageView = findViewById(R.id.number_text_view);
        myImageView1 = findViewById(R.id.number_B_text_view);
        //load the animation file (my_anim)
        myAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.my_anim);
        myAnimation1 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.my_anim);
        myAnimation2 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.my_anim1);

    }

    /**
     * This method is called when the order button is clicked.
     */


    public void point_3(View view) {
        scoreTeamA += 3;
        display(scoreTeamA);
        myImageView.startAnimation(myAnimation);


    }

    public void point_2(View view) {
        scoreTeamA += 2;
        display(scoreTeamA);
        myImageView.startAnimation(myAnimation);


    }

    public void FreeThrow(View view) {
        scoreTeamA++;
        display(scoreTeamA);
        myImageView.startAnimation(myAnimation);


    }


    public void point_3_B(View v) {
        scoreTeamB += 3;
        display3(scoreTeamB);
        myImageView1.startAnimation(myAnimation1);

    }

    public void point_2_B(View v) {
        scoreTeamB += 2;
        display3(scoreTeamB);
        myImageView1.startAnimation(myAnimation1);

    }

    public void FreeThrow_B(View v) {
        scoreTeamB += 1;
        display3(scoreTeamB);
        myImageView1.startAnimation(myAnimation1);

    }


    public void finesh(View v) {

        if (scoreTeamB > scoreTeamA) {
            display2(winner);
            display1(loser);
        } else {
            display1(winner);
            display2(loser);
        }
        if (scoreTeamA == scoreTeamB) {
            display1(same);
            display2(same);
        }
    }

    public void Reset(View v) {
        scoreTeamA = 0;
        scoreTeamB = 0;
        display(scoreTeamA);
        display3(scoreTeamB);
        myImageView.startAnimation(myAnimation2);
        myImageView1.startAnimation(myAnimation2);
    }

    private void display(int number) {
        TextView mediumTextView = (TextView) findViewById(R.id.number_text_view);
        mediumTextView.setText("" + number);
    }

    private void display1(String loser) {
        TextView mediumTextView = (TextView) findViewById(R.id.finsh_text_view);
        mediumTextView.setText("" + loser);
    }

    private void display2(String winner) {
        TextView mediumTextView = (TextView) findViewById(R.id.finsh_B_text_view);
        mediumTextView.setText("" + winner);
    }

    private void display3(int number) {
        TextView mediumTextView = (TextView) findViewById(R.id.number_B_text_view);
        mediumTextView.setText("" + number);
    }

}